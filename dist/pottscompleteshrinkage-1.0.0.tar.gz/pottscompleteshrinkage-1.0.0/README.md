# Potts Complete Shrinkage
Potts Clustering with Complete Shrinkage

## Installation
Install using pip
```pip install pottscompleteshrinkage```

## Requirements
* Python 3.6 or greater
* numpy
* pandas

## Usage
Run on command line: pottscompleteshrinkage -h